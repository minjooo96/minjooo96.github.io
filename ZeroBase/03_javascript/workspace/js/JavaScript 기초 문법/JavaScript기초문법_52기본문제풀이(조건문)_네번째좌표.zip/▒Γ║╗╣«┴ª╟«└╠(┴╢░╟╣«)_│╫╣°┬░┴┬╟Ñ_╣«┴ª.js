/*** 5. 네번째 좌표 ***/

/* user code */
function answer(x_arr, y_arr) {
  let result = [];

  let offset = [];
  for (let i = 0; i < x_arr.length; i++) {
    offset[i] = [ x_arr[i], y_arr[i] ];
  }
  offset.sort();

  for (let i = 0; i < offset.length; i++) {
    for (let j = 0; j < offset[i].length; j++) {
      if( offset[i][0] !== offset[j][0] ){
        if( offset[i][1] !== offset[j][1] ){
          offset.push( offset[j][1], offset[i][1] );
        }
      }
    }
  }
  console.log(offset);

  return result;
}

/* main code */
let input = [
  // TC: 1
  [
    [5, 5, 8],
    [5, 8, 5],
  ],
  // TC: 2
  [
    [3, 1, 1],
    [2, 1, 2],
  ],
  // TC: 3
  [
    [7, 7, 3],
    [4, 1, 1],
  ],
];
for (let i = 0; i < input.length; i++) {
  process.stdout.write(`#${i + 1} `);
  console.log(answer(input[i][0], input[i][1]));
}
